"""
This is the Template Repl for Python with Turtle.

Python with Turtle lets you make graphics easily in Python.

Check out the official docs here: https://docs.python.org/3/library/turtle.html
"""

import turtle

t = turtle.Turtle()
# Comment block
"""
for c in ['red', 'green', 'blue', 'pink']:
    t.color(c)
    t.forward(75)
    t.right(90)
"""

t.color("red")
t.forward(75)
t.right(90)
t.forward(75)
t.right(90)
t.forward(100)
t.right(90)
t.forward(75)
t.right(90)
t.forward(25)
t.forward(25)
t.forward(50)
t.left(132)
t.forward(75)
t.left(95)
t.forward(75)
#t.penup()
# Draw sun
t.penup()
t.forward(100)
t.right(90)
t.forward(300)
t.pendown()
t.color("yellow")
size= 50
t.circle(size)
# sunlight
t.penup()
t.forward(30)
t.right(90)
t.pendown()
t.forward(75)
t.color("yellow")
# sunlight
t.penup()
t.backward(60)
t.right(90)
t.forward(75)
t.pendown()
t.left(40)
t.forward(50)
t.color("yellow")
#more sunlight
t.penup()
t.backward(60)
t.right(90)
t.forward(75)
t.pendown()
t.left(40)
t.forward(50)
t.color("yellow")















