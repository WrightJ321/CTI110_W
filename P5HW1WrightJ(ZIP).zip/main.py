# CTI 110
# P5HW1-Math quiz
# Jacob Wright
# 11/9/23

import random

# Guess loop to collect all guesses
#Set a variable for random numbers
num = random.randint(1, 1000)

#Let user choose from a menu to play a math game
def main_menu():
  print("Welcome to the Super Awesome Math Game!")
  print("Main Menu", sep="")
  print("-"*20)
  #Within the math game, user can choose to add or subtract random numbers
  print("1. Add Random Numbers")
  print("2. Subtract Random Numbers")
  print("3. Exit the game.")
  choice = input("Please choose one of the options: ")
  if choice == '1':
    add_num()
  elif choice == '2':
    sub_num()
  elif choice == '3':
    choice = input("Math is so fun! Are you sure you want to exit? Y/N?")
    if choice == "Y":
      print("Ok Goodbye.")
    elif choice == "N":
      main_menu()
  else:
    print("Please choose from the following.")
    main_menu()
    #User continues to play until they choose to exit the game
def add_num():
  num_1 = num
  num_2 = num
  sum = num_1 + num_2
  print("\t ", num_1, sep="")
  print("  +\t", num_2)
  answer = int(input("Enter your answer: "))
  total_guesses = 0
  while answer != sum:
    print("\t ", num_1, sep="")
    print("  +\t", num_2)
    print("That answer is incorrect, Try again: ")
    print("Enter another answer: ")
    answer = int(input())
    total_guesses = total_guesses + 1
  if answer == sum:
    print("NICE! You are correct!")
  total_guesses = total_guesses + 1
  print("total number of incorrect guesses: ", total_guesses)
  main_menu()
#might need to do for loop for guesses
#Need to tally up guesses
def sub_num():
  num_1 = num
  num_2 = num
  difference = num_1 - num_2
  print("\t ", num_1, sep="")
  print("  -\t", num_2)
  answer = int(input("Enter your answer: "))
  total_guesses = 0
  while answer != difference:
    print("\t ", num_1, sep="")
    print("  -\t", num_2)
    print("That answer is incorrect, Try again: ")
    print("Enter another answer: ")
    answer = int(input())
    total_guesses = total_guesses + 1
  if answer == difference:
    print("NICE! You are correct!")
  total_guesses = total_guesses + 1
  print("total number of incorrect guesses: ", total_guesses)
  main_menu()
#Game tracks number of incorrect guesses

def main():
  main_menu()
main()
