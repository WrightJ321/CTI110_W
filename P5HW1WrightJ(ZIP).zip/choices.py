#choices.py
def choice_menu(choice_1, choice_2, choice_3):
  print("Menu:")
  print(f"1. {choice_1}")
  print(f"2. {choice_2}")
  print(f"3. {choice_3}")


  while True:
      user_choice = input("Choose 1, 2, 3")
      if user_choice in ['1', '2', '3']:
          return user_choice
      else:
          print("Invalid choice. Please try again.")