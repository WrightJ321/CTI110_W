#choices.py
def choice_menu(choice_1, choice_2):
  print("Menu:")
  print(f"1. {choice_1}")
  print(f"2. {choice_2}")
  

  while True:
      user_choice = input("Choose 1, 2 ")
      if user_choice in ['1', '2']:
          return user_choice
      else:
          print("Invalid choice. Please try again.")