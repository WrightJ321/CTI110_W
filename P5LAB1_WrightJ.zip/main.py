# CTI 110
# P5LAB1 - CYOA
# name
# date
# Feel free to fork this REPL and make changes.

# first function: main_menu().

from choices import choice_menu


def main_menu():
    print("Main Menu")
    print("You're in front of a spooky old house...")
    print("Do you:")
    print("1. Try the front door")
    print("2. Sneak around back")
    print("3. Forget it and go home")
    print("4. Use Key to open front door")
    choice = input("Choose: ")
    if choice == '1':
        choice_front_door()
    elif choice == '2':
        # Call choice 2 here (You can add the corresponding function)
        choice_back_door()
    elif choice == '3':
        # Call choice 3 here (You can add the corresponding function)
        choice_go_home()
    elif choice == '4':
        choice_Key()
      #Phrase = "This key holds the power to untold riches"
    elif choice == '5':
        print("Ok, goodbye.")
        return
    else:
        print("That's not a valid choice, please try again.")
        main_menu()

# now we have the choice functions. Feel free to add more.
def choice_front_door():
    print("You tried the front door.")
    print("It's locked.")
    print("Do you:")
    print("1. Check around back")
    print("2. Give up and go home")
    choice = input("Choose: ")
    if choice == '1':
        choice_back_door()
    elif choice == '2':
        choice_go_home()
    else:
        print("You have to choose...")
        choice_front_door()

def choice_back_door():
    print("You see a back door and a shed.")
    print("The Back door has a deadbolt and chain attached to the door handle.")
    choice = choice_menu("Look in the Shed","Kick down the back door" )
    if choice == '1': #shed
      print("As you go into the shed you see a rusted key lying on the floor")
      choice_getout_shed()
    elif choice == '2': # kick the back door down
      print(" As you attempt to kick the door, it spawns a ghostly foot and kicks you into the shed where you find a key with the phrase,*This key holds the power to untold riches*.")
      print("You dust yourself off")
  
      choice_getout_shed()
    else:
      print("You must choose an option!")
      choice_back_door()
def choice_Key():
    print("To utilize key say the phrase etched on the key")
    choice = choice_menu("This key holds the power to untold riches", "User beware this key will be the death of you!")
    if choice == '1': # correct phrase
      print("This key holds the power to untold riches")
      choice_inside()
    elif choice == '2':
      print("Incorrect, you do not have the right key")
      choice_front_door()
    else:
      print("You have to choose...")
      choice_Key()
def choice_inside():
  print("The front door unlocks.")
  choice = choice_menu("walk inside?", "Pull out a lighter and use it as a light to light up the room?")
  
def choice_go_home():
    print("1.Walk home to eat cookies and milk.")
    print("2.Call your buddy to meet up at bar on the way home to tell him about the house.")
    choice = input("Choose: ")
    if choice == '1':
     print("Once you're home you see your plate of cookies on your kitchen counter and take a bite out of one... suddenly you feel sick and pass out.")
    elif choice == '2':
     print("You go to the bar have a couple drinks and talk about the spooky house with your buddy.")
     main_menu()
    else:
     print("You must choose an option!")
    choice_go_home()
def choice_getout_shed():
  print("You see a rusted chest glowing green.")
  choice = choice_menu("Go back to the front door to use the key?", "look inside the oddly colored chest?")
  if choice == '1':
    main_menu()
  elif choice == '2':
      print("You open the glowing chest and green acid is spewed onto your entire body killing you instantly.")
    
  else:
    print("You must choose an option!")
    choice_getout_shed()
# finally, we have main -- which we use to start the program 
def main():
    print("M5LAB1 - Choose Your Own Adventure")
    main_menu()
    print("Thank You see you next time.....if you're brave enough...")

#start the program
main()
